﻿namespace MAUISampleDemo.Helpers
{
    public interface IToast
    {
        void MakeToast(string message);
    }
}
