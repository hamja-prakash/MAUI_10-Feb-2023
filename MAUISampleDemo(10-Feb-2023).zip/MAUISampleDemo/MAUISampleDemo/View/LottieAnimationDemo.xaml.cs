namespace MAUISampleDemo.View;

public partial class LottieAnimationDemo : ContentPage
{
	public LottieAnimationDemo()
	{
		InitializeComponent();
	}
}