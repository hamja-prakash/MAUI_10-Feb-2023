namespace MAUISampleDemo.View;

public partial class ImagechangecolorDemo : ContentPage
{
	public ImagechangecolorDemo()
	{
		InitializeComponent();
	}
}